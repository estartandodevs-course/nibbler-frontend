import { Component } from '@angular/core';

@Component({
  selector: 'app-home-diary',
  templateUrl: './home-diary.component.html',
  styleUrl: './home-diary.component.scss'
})
export class HomeDiaryComponent {

}
